<link href="{{asset('frontend/assests/css/offer-product-loop.css')}}" rel="stylesheet">

<div class="offer-product-wrapper">
    <div class="offer-product-image" style="background-image: url('frontend/assests/images/asus-rog-laptop.png');"></div>
    <h4 class="offer-product-title">Asus Rog Laptop</h4>
</div>