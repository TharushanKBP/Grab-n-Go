@include('frontend.layouts.header')

@include('frontend.pages.single_product')

@include('frontend.layouts.footer')