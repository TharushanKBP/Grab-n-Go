@include('frontend.layouts.header')

@include('frontend.pages.shop')

@include('frontend.layouts.footer')